<p align="center">
  <img src="capa-ebook.svg" alt="Capa do eBook Emagrecer Sem Sofrer" width="350"/>
</p>

# Emagrecer Sem Sofrer: Guia Completo para o Emagrecimento Saudável

---

## Sumário

1. [Introdução](#introducao)
2. [Por que Engordamos?](#por-que-engordamos)
3. [Princípios do Emagrecimento Saudável](#principios-do-emagrecimento-saudavel)
4. [Alimentação Inteligente](#alimentacao-inteligente)
5. [Exercício Físico: Seu Aliado](#exercicio-fisico-seu-aliado)
6. [Psicologia do Emagrecimento](#psicologia-do-emagrecimento)
7. [Dicas Práticas para o Dia a Dia](#dicas-praticas-para-o-dia-a-dia)
8. [Receitas Saudáveis](#receitas-saudaveis)
9. [Erros Comuns e Como Evitá-los](#erros-comuns-e-como-evita-los)
10. [Conclusão](#conclusao)
11. [Referências](#referencias)

---

## 1. Introdução

O emagrecimento saudável vai muito além de dietas restritivas e sacrifícios. Trata-se de um processo de autoconhecimento e transformação de hábitos que pode ser prazeroso e sustentável. Este guia foi criado para te ajudar a emagrecer de forma leve, sem sofrimento, com saúde e bem-estar!

---

## 2. Por que Engordamos?

Engordar é resultado de uma combinação de fatores, como:

- Consumo calórico acima do gasto energético
- Sedentarismo
- Fatores emocionais (ansiedade, estresse)
- Genética e metabolismo
- Maus hábitos alimentares

O segredo do emagrecimento está no equilíbrio entre alimentação, atividade física e saúde mental.

---

## 3. Princípios do Emagrecimento Saudável

- **Déficit Calórico:** Gaste mais calorias do que consome.
- **Qualidade Nutricional:** Prefira alimentos naturais e minimamente processados.
- **Consistência:** Pequenas mudanças mantidas a longo prazo trazem resultados duradouros.
- **Respeite seu corpo:** Emagrecer rápido não é saudável. Cada organismo tem seu tempo.

---

## 4. Alimentação Inteligente

- **Coma devagar:** A saciedade demora a chegar ao cérebro.
- **Inclua fibras:** Frutas, legumes e grãos integrais aumentam a saciedade.
- **Evite ultraprocessados:** São ricos em calorias, açúcares e gorduras ruins.
- **Hidrate-se:** Muitas vezes confundimos sede com fome.
- **Planeje suas refeições:** Isso evita escolhas impulsivas.

#### Alimentos aliados do emagrecimento:
- Verduras e legumes
- Frutas frescas
- Carnes magras e ovos
- Grãos integrais
- Oleaginosas em pequenas quantidades

#### Atenção:
Dietas extremamente restritivas podem causar efeito rebote e prejudicar a saúde.

---

## 5. Exercício Físico: Seu Aliado

A atividade física acelera o metabolismo, preserva a massa muscular e melhora o humor.

- **Escolha uma atividade que goste:** Caminhada, dança, musculação, ciclismo, etc.
- **Comece devagar:** O importante é criar o hábito.
- **Inclua exercícios de força:** Ajudam a manter o músculo e queimar mais calorias.
- **Mexa-se sempre que possível:** Suba escadas, caminhe mais, faça alongamentos.

---

## 6. Psicologia do Emagrecimento

- **Autoconhecimento:** Identifique gatilhos de comer emocional.
- **Estabeleça metas realistas:** Pequenos objetivos são mais fáceis de alcançar.
- **Não se compare:** Cada corpo tem seu ritmo.
- **Celebre conquistas:** Valorize cada progresso, por menor que seja.

---

## 7. Dicas Práticas para o Dia a Dia

- Tenha lanches saudáveis à mão (frutas, castanhas)
- Não pule refeições
- Coma em pratos menores, ajuda a controlar a porção
- Durma bem: o sono influencia no peso
- Evite bebidas açucaradas e refrigerantes

---

## 8. Receitas Saudáveis

### Panqueca de Banana

**Ingredientes:**
- 1 banana madura
- 1 ovo
- 2 colheres (sopa) de aveia

**Modo de preparo:**
1. Amasse a banana, misture com o ovo e a aveia.
2. Coloque em uma frigideira antiaderente e doure dos dois lados.
3. Sirva com canela ou frutas.

---

### Salada Colorida

**Ingredientes:**
- Folhas verdes variadas
- Tomate-cereja
- Cenoura ralada
- Pepino fatiado
- 1 colher (sopa) de azeite de oliva

**Modo de preparo:**
1. Misture tudo e tempere com azeite, limão e pouco sal.

---

## 9. Erros Comuns e Como Evitá-los

- Buscar resultados imediatos
- Cortar grupos alimentares inteiros sem orientação
- Exagerar nos “dias do lixo”
- Negligenciar o sono e o estresse

---

## 10. Conclusão

O emagrecimento saudável é um processo de mudança de hábitos. Com persistência, autoconhecimento e pequenas escolhas diárias, é possível emagrecer sem sofrimento e com saúde. Lembre-se: cada passo conta!

---

## 11. Referências

- Sociedade Brasileira de Endocrinologia e Metabologia (SBEM)
- Organização Mundial da Saúde (OMS)
- Associação Brasileira para o Estudo da Obesidade e Síndrome Metabólica (ABESO)
- Artigos científicos sobre alimentação e atividade física

---

> **Este eBook é apenas informativo e não substitui orientação de profissionais de saúde. Procure sempre acompanhamento médico e nutricional para emagrecer com segurança.**